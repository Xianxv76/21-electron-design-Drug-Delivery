#ifndef __TASK_CAR_H
#define __TASK_CAR_H

#include "sys.h"
#include "encoder_task.h"
#include "vision.h"
#include "led.h"
#include "timer.h"



void task_one(void);
void  xunxian_one(int mod);


#endif

