#ifndef __OPENMV_H_
#define __OPENMV_H_

#include "sys.h"

void open_init(void);

#endif

