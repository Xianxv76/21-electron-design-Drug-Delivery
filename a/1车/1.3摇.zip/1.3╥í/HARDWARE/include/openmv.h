#ifndef __ENCODER_TASK_H_
#define __ENCODER_TASK_H_

#include "sys.h"


void open_init(void);

#endif

