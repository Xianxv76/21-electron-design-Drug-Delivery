#ifndef __TASK_THREE_H
#define __TASK_THREE_H

#include "sys.h"
#include "encoder_task.h"
#include "vision.h"
#include "led.h"
#include "timer.h"


void task_three(void);
void xunxian_two(int mod);
void xunxian_three(int mod);

#endif

