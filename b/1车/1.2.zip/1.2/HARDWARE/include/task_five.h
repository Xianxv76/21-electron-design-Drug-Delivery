#ifndef __TASK_FIVE_H
#define __TASK_FIVE_H

#include "sys.h"
#include "encoder_task.h"
#include "task_three.h"
#include "task_two.h"
#include "vision.h"
#include "led.h"
#include "timer.h"


void task_four(void);
void xunxian_two(int mod);
void xunxian_three(int mod);
void xunxian_four(int mod);
void xunxian_five(int mod);
void task_five(void);

#endif

