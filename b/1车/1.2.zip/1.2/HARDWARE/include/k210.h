#ifndef _K210_H
#define _K210_H

#include "sys.h"

void k210_init(void);



#endif

